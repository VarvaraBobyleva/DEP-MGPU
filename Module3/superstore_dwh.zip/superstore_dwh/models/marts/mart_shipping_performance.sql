--Выполнение этого запроса предоставит таблицу, в которой будут перечислены способы доставки, общее количество заказов для каждого из них и их средняя прибыльность.
SELECT
    sto.ship_mode,
    COUNT(order_id) AS total_orders,
    AVG(profit) AS average_profit
FROM {{ ref('stg_orders') }} AS sto
GROUP BY
    sto.ship_mode
ORDER BY
    average_profit DESC