with customer_first_purchase as (
    select
        customer_id,
        min(date_trunc('month', order_date))::date as cohort_month
    from {{ ref('int_sales_orders') }}
    group by 1
)

select * from customer_first_purchase