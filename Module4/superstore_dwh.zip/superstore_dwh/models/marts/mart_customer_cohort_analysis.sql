with orders as (
    select
        customer_id,
        order_date,
        sales
    from {{ ref('int_sales_orders') }} 
),

customers as (
    select * from {{ ref('int_customer_cohorts') }}
),

orders_with_cohort as (
    select
        o.customer_id,
        o.order_date,
        o.sales,
        c.cohort_month,
        (extract(year from o.order_date) - extract(year from c.cohort_month)) * 12 +
        (extract(month from o.order_date) - extract(month from c.cohort_month)) as months_since_first_purchase
    from orders as o
    join customers as c
        on o.customer_id = c.customer_id
),

three_month_sales as (
    select
        cohort_month,
        sum(sales) as cumulative_sales_3_months
    from orders_with_cohort
    where months_since_first_purchase between 0 and 2
    group by 1
)

select * from three_month_sales
order by cohort_month